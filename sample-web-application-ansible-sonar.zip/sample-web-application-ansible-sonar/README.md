

# Build Instruction


```
mvn clean package
```

# Deploy instruction

Deploy ```target/WebApp.war``` on Tomcat 

